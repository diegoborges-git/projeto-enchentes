# Quadros do relatório BID/CEPAL/Banco Mundial – Inundações no RS (IDB-TN-03039)

137 quadros extraídos do PDF (todos os quadros do índice oficial, 1 a 133 e 15a–15e). Um CSV por quadro + `_indice_quadros.csv`.

## Convenções dos CSVs
- UTF-8, separador vírgula, decimal com ponto, sem separador de milhar.
- Valores monetários seguem a unidade do título do quadro (em geral, milhares de R$).
- Percentuais viram número (46,2% → 46.2) e o cabeçalho ganha “(%)”.
- Traço “-” do PDF = célula vazia.
- Linhas “Total” foram mantidas: filtre-as para não somar em dobro no dashboard.
- Rótulos de células mescladas foram repetidos nas linhas; títulos internos viraram a coluna `Seção`.
- Quadros 10 e 11 (óbitos e desaparecidos por município) foram despivotados para formato longo (Município, valor).
- Gráficos e mapas (imagens) não foram extraídos; só tabelas numeradas.

## Validação
- Completude: para cada quadro, todos os números impressos entre a legenda e a “Fonte” foram encontrados no CSV (0 faltando).
- Soma das linhas = linha Total: confere em 92 quadros; 30 não têm linha Total; 15 divergem (ver abaixo).
- Divergências esperadas (tabelas não aditivas, listas parciais de municípios, blocos com seções, colunas acumuladas): Q15C, Q28, Q33, Q38, Q91, Q92, Q98, Q104, Q111, Q125, Q127, Q128, Q129.
- Q3 diverge em 1 coluna (tabela hierárquica) e deve ser revisado antes de uso.

## Inconsistências do próprio relatório (mantidas como publicadas)
- Quadro 2: rótulos Social e Infraestrutura estão trocados (Quadro 3 e as somas dos setores mostram Social = 11.605.088 e Infraestrutura = 4.449.312 nos danos).
- Quadro 41: total privado impresso 168.749; as parcelas somam 173.774.
- Quadro 11: “Rocas Sales” (grafia diferente de “Roca Sales” no Quadro 10).
- Quadro 113: usa vírgula como separador de milhar (35,875 = 35.875); já normalizado.

## Correções de digitação aplicadas (evidência: soma das linhas/colunas)
- Quadro 3, Perdas do setor Produtivo: "3.0474.606" -> 30.474.606 (confere com o Quadro 2)
- Quadro 15d: letra de nota de rodapé removida de "8,03b" -> 8,03
- Quadro 15d: letra de nota de rodapé removida de "79,67b" -> 79,67
- Quadro 15d: letra de nota de rodapé removida de "84,81b" -> 84,81
- Quadro 15d: letra de nota de rodapé removida de "82,24b" -> 82,24
- Quadro 15d: letra de nota de rodapé removida de "83,52b" -> 83,52
- Quadro 63, Total da EGR: "197.87" truncado -> 197.875 (igual à coluna Privado)
- Quadro 73, CEEE-D, população atendida: "3. 799.079" -> 3.799.079
- Quadro 73, CERILUZ, área km2: "619." -> 619
- Quadro 85, TOTAL: dígito de nota de rodapé colado ("10.567.7863") -> 10.567.786 (soma das linhas)
- Quadro 87, Total Maquinário: "273.991.200" -> 273.992 (soma das linhas)
- Quadro 90, Bergamota: "1 %" -> 1%
- Quadro 90, Total: dígito de nota de rodapé colado ("11.059.8728") -> 11.059.872
- Quadro 91: cabeçalho embaralhado por texto sobreposto no PDF; reconstruído como Cultivo / Perdas / Porcentagem / Acumulado
- Quadro 109, Fabricação de veículos: "4..476696" -> 4.476.696 (soma da coluna)
- Quadro 121, Inundações, Total: "1.47.534" -> 1.474.534 (danos + perdas)
- Quadro 121, Total das perdas: "11.585.882" -> 1.585.882 (soma e Quadro 2)
- Quadro 126, cabeçalho da 1ª coluna sem a palavra "Estratos" no PDF (completado conforme o Quadro 125)
